# SDG 4 — AI in Education (MPU3193)

Static, multi-page site for GitHub Pages (HTML+CSS only).

## Deploy
1) Create a new GitHub repo.
2) Upload these files to the repo root.
3) Settings → Pages → Deploy from a branch → `main`.
4) Open the Pages URL.
